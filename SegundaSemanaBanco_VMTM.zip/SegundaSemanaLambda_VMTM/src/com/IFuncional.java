package com;

@FunctionalInterface
public interface IFuncional {
	//INTERFACE FUNCIONAL ES AQUELLA QUE SOLO TIENE UN METODO 
	//ABSTRACTO DECLARADO
	//PARA DELIMITARLO AL 100% COMO INTERFACE FUNCIONAL SE PUEDE AGREGAR UN DECORADOR
	//@FunctionalInterface
	public void operacion(double a, double b);
	
}
