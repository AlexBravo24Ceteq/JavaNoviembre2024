package com;

public interface ITermometro {
	public void temperaturaCelsius();
	public void temperaturaFarenheit();

}
